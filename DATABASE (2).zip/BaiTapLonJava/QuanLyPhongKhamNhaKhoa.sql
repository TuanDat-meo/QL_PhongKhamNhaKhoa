﻿-- Bảng bệnh nhân --
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    DateOfBirth DATE,
    Gender VARCHAR(10),
    PhoneNumber VARCHAR(15) NOT NULL,
    Address VARCHAR(200),
    Email VARCHAR(100)
);
-- Bảng Nha Sĩ --
CREATE TABLE Dentists (
    DentistID INT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Specialty VARCHAR(50),
    PhoneNumber VARCHAR(15),
    Email VARCHAR(100)
);
-- Bảng Lịch Hẹn --
CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY,
    PatientID INT,
    DentistID INT,
    AppointmentDate DATETIME NOT NULL,
    Reason VARCHAR(200),
    Status VARCHAR(20),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DentistID) REFERENCES Dentists(DentistID)
);
-- Bảng Dịch Vụ --
CREATE TABLE Services (
    ServiceID INT PRIMARY KEY,
    ServiceName VARCHAR(100) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL
);
-- Bảng Hóa Đơn --
CREATE TABLE Invoices (
    InvoiceID INT PRIMARY KEY,
    PatientID INT,
    AppointmentID INT,
    TotalAmount DECIMAL(10, 2),
    InvoiceDate DATE,
    PaymentStatus VARCHAR(20),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (AppointmentID) REFERENCES Appointments(AppointmentID)
);
-- Bảng chi tiết hóa đơn --
CREATE TABLE InvoiceDetails (
    DetailID INT PRIMARY KEY,
    InvoiceID INT,
    ServiceID INT,
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    FOREIGN KEY (InvoiceID) REFERENCES Invoices(InvoiceID),
    FOREIGN KEY (ServiceID) REFERENCES Services(ServiceID)
);
-- Bảng Bảo Hiểm Y Tế
CREATE TABLE HealthInsurance (
    InsuranceID INT PRIMARY KEY,
    PatientID INT,
    InsuranceProvider VARCHAR(100),
    PolicyNumber VARCHAR(50),
    StartDate DATE,
    EndDate DATE,
    CoverageDetails VARCHAR(200),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID)
);
-- Bảng Điều Trị
CREATE TABLE Treatments (
    TreatmentID INT PRIMARY KEY,
    AppointmentID INT,
    ServiceID INT,
    DentistID INT,
    TreatmentDate DATE,
    Description TEXT,
    Result VARCHAR(50),
    FOREIGN KEY (AppointmentID) REFERENCES Appointments(AppointmentID),
    FOREIGN KEY (ServiceID) REFERENCES Services(ServiceID),
    FOREIGN KEY (DentistID) REFERENCES Dentists(DentistID)
);
-- Bảng Hồ Sơ Bệnh Án
CREATE TABLE MedicalRecords (
    RecordID INT PRIMARY KEY,
    PatientID INT,
    TreatmentID INT,
    Diagnosis VARCHAR(200),
    Prescription TEXT,
    RecordDate DATE,
    Notes TEXT,
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (TreatmentID) REFERENCES Treatments(TreatmentID)
);

-- Bảng Quản Lý Nha Sĩ
CREATE TABLE DentistManagement (
    ManagementID INT PRIMARY KEY,
    DentistID INT,
    ScheduleDate DATE,
    StartTime TIME,
    EndTime TIME,
    Status VARCHAR(20),
    FOREIGN KEY (DentistID) REFERENCES Dentists(DentistID)
);

-- Bảng Sản Phẩm
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    UnitPrice DECIMAL(10, 2) NOT NULL,
    StockQuantity INT
);

-- Bảng Quản Lý Bán Hàng
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    PatientID INT,
    ProductID INT,
    Quantity INT,
    SaleDate DATE,
    TotalPrice DECIMAL(10, 2),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
-- Bảng Nhà Cung Cấp Labo
CREATE TABLE LabSuppliers (
    SupplierID INT PRIMARY KEY,
    SupplierName VARCHAR(100) NOT NULL,
    ContactPerson VARCHAR(50),
    PhoneNumber VARCHAR(15),
    Email VARCHAR(100),
    Address VARCHAR(200)
);

-- Bảng Danh Mục Sản Phẩm Labo
CREATE TABLE LabProducts (
    LabProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50),
    UnitPrice DECIMAL(10, 2),
    Unit VARCHAR(20)
);

-- Bảng Đơn Hàng Labo
CREATE TABLE LabOrders (
    OrderID INT PRIMARY KEY,
    SupplierID INT,
    OrderDate DATE,
    DeliveryDate DATE,
    TotalAmount DECIMAL(10, 2),
    OrderStatus VARCHAR(20),
    FOREIGN KEY (SupplierID) REFERENCES LabSuppliers(SupplierID)
);

-- Bảng Chi Tiết Đơn Hàng Labo
CREATE TABLE LabOrderDetails (
    DetailID INT PRIMARY KEY,
    OrderID INT,
    LabProductID INT,
    QuantityOrdered INT,
    QuantityReceived INT,
    UnitPrice DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES LabOrders(OrderID),
    FOREIGN KEY (LabProductID) REFERENCES LabProducts(LabProductID)
);

-- Bảng Nhận Hàng Labo
CREATE TABLE LabReceipts (
    ReceiptID INT PRIMARY KEY,
    OrderID INT,
    ReceiptDate DATE,
    ReceivedBy VARCHAR(50),
    Notes TEXT,
    FOREIGN KEY (OrderID) REFERENCES LabOrders(OrderID)
);